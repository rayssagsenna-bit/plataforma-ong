// scripts básicos: ano, máscaras e validação
document.addEventListener('DOMContentLoaded',function(){
  const ano = document.getElementById('ano');
  if(ano) ano.textContent = new Date().getFullYear();

  function cpfMask(v){
    v=v.replace(/\D/g,'');
    v=v.replace(/(\d{3})(\d)/,'$1.$2');
    v=v.replace(/(\d{3})(\d)/,'$1.$2');
    v=v.replace(/(\d{3})(\d{1,2})$/,'$1-$2');
    return v;
  }
  function telMask(v){
    v=v.replace(/\D/g,'');
    if(v.length>10){
      v=v.replace(/(\d{2})(\d{5})(\d{4})/,'($1) $2-$3');
    } else {
      v=v.replace(/(\d{2})(\d{4})(\d{4})/,'($1) $2-$3');
    }
    return v;
  }
  function cepMask(v){
    v=v.replace(/\D/g,'');
    v=v.replace(/(\d{5})(\d{3})/,'$1-$2');
    return v;
  }

  var cpf = document.getElementById('cpf');
  if(cpf) cpf.addEventListener('input',function(){ this.value = cpfMask(this.value); });
  var tel = document.getElementById('telefone');
  if(tel) tel.addEventListener('input',function(){ this.value = telMask(this.value); });
  var cep = document.getElementById('cep');
  if(cep) cep.addEventListener('input',function(){ this.value = cepMask(this.value); });

  var form = document.getElementById('form-cadastro');
  if(form){
    form.addEventListener('submit',function(e){
      if(!form.checkValidity()){
        e.preventDefault();
        form.reportValidity();
      } else {
        e.preventDefault();
        alert('Cadastro enviado (simulação) — ver README para instruções de deploy.');
      }
    });
  }
});
