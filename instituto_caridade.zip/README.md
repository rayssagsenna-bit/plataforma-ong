# Instituto Caridade — Plataforma Social (Entrega 1 — HTML5)

## Conteúdo
- index.html
- projetos.html
- cadastro.html
- css/style.css
- js/script.js
- assets/images/* (imagens placeholder SVG)

## Como publicar no GitHub Pages (resumo)
1. Crie um repositório público no GitHub chamado `plataforma-ong`.
2. Faça upload dos arquivos pelo navegador (Add file → Upload files).
3. Em Settings → Pages, selecione Branch `main` e /root, salve.
4. Aguarde e acesse: https://SEU-USUARIO.github.io/plataforma-ong

## Observações
- O formulário faz validação HTML5 e máscaras em JavaScript.
- Mantenha o repositório público para que a correção funcione.
